@echo off
echo ============================================
echo  AutoBiz - Push All Updates to GitHub
echo ============================================
cd /d "%~dp0"
git add -A
git commit -m "feat: Multi-branch, Document Vault, AI AutoPilot, Charts, Self-Booking, Customer AI Concierge"
git push origin main
echo.
echo DONE! Check https://autobiz-app.onrender.com
pause
